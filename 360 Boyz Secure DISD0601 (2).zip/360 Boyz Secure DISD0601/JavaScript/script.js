

// Administrator email
const adminEmail = "ST10510907@rcconnect.edu.za";

// Get both forms
const contactForm = document.getElementById("contactForm");
const enquiryForm = document.getElementById("enquiryForm");

// Validation function
function checkFormStatus(form) {

    let valid = true;

    const name = form.querySelector("#name").value.trim();
    const email = form.querySelector("#email").value.trim();
    const phone = form.querySelector("#phone").value.trim();
    const message = form.querySelector("#message").value.trim();

    const namePattern = /^[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ\s'-]*$/;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phonePattern = /^\+?[0-9\s()-]{7,20}$/;

    // Clear previous error messages
    form.querySelectorAll(".error").forEach(function (error) {
        error.innerHTML = "";
    });

    // Check name
    if (name == "") {
        form.querySelector("#nameError").innerHTML =
            "Please enter your full name.";
        valid = false;

    } else if (!namePattern.test(name)) {
        form.querySelector("#nameError").innerHTML =
            "Please enter a valid name.";
        valid = false;
    }

    // Check email
    if (email == "") {
        form.querySelector("#emailError").innerHTML =
            "Please enter your email address.";
        valid = false;

    } else if (!emailPattern.test(email)) {
        form.querySelector("#emailError").innerHTML =
            "Please enter a valid email address.";
        valid = false;
    }

    // Check phone
    if (phone == "") {
        form.querySelector("#phoneError").innerHTML =
            "Please enter your phone number.";
        valid = false;

    } else if (!phonePattern.test(phone)) {
        form.querySelector("#phoneError").innerHTML =
            "Please enter a valid phone number.";
        valid = false;
    }

    // Check message
    if (message == "") {
        form.querySelector("#messageError").innerHTML =
            "Please enter your message.";
        valid = false;

    } else if (message.length < 10) {
        form.querySelector("#messageError").innerHTML =
            "Message must contain at least 10 characters.";
        valid = false;
    }

    // Additional validation for enquiry page
    if (form.id == "enquiryForm") {

        const service = form.querySelector("#service").value;
        const location = form.querySelector("#location").value.trim();

        if (service == "") {
            form.querySelector("#serviceError").innerHTML =
                "Please select a service.";
            valid = false;
        }

        if (location == "") {
            form.querySelector("#locationError").innerHTML =
                "Please enter your location.";
            valid = false;
        }
    }

    return valid;
}


// Function to submit form information
async function submitForm(form, submitBtn, formStatus) {

    if (!checkFormStatus(form)) {
        return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = "Sending...";

    formStatus.innerHTML = "Submitting your information...";

    try {

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        const response = await fetch(
            "https://formsubmit.co/ajax/" + encodeURIComponent(adminEmail),
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },

                body: JSON.stringify(data)
            }
        );

        const result = await response.json();

        if (response.ok && result.success) {

            formStatus.innerHTML =
                "Thank you! Your information was submitted successfully.";

            form.reset();

        } else {

            formStatus.innerHTML =
                "Submission failed. Please try again.";

        }

    } catch (error) {

        formStatus.innerHTML =
            "An error occurred. Please check your internet connection.";

    } finally {

        submitBtn.disabled = false;

        submitBtn.textContent =
            form.id == "contactForm"
            ? "Submit Message"
            : "Submit Enquiry";
    }
}


// Contact Us form
if (contactForm) {

    contactForm.addEventListener("submit", function (event) {

        event.preventDefault();

        const submitBtn = contactForm.querySelector("#submitBtn");
        const formStatus = contactForm.querySelector("#formStatus");

        submitForm(contactForm, submitBtn, formStatus);

    });
}


// Enquiry form
if (enquiryForm) {

    enquiryForm.addEventListener("submit", function (event) {

        event.preventDefault();

        const submitBtn = enquiryForm.querySelector("#submitBtn");
        const formStatus = enquiryForm.querySelector("#formStatus");

        submitForm(enquiryForm, submitBtn, formStatus);

    });
}















//DATE AND TIME FUNCTION
function updateDateTime() {
    const now = new Date();
    const options = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
    };
    const datetimeElement = document.getElementById("datetime");
    if (datetimeElement) {

        datetimeElement.textContent =
            now.toLocaleString("en-ZA", options);

    }

}

// Display date and time immediately
updateDateTime();

// Update date and time every second
setInterval(updateDateTime, 1000);




/* =====================================
   360 BOYZ SECURE SLIDESHOW
===================================== */

let slideIndex = 0;

const slides = document.querySelectorAll(".slide");

function showSlide(index) {

    if (slides.length === 0) {
        return;
    }

    slides.forEach(function(slide) {
        slide.style.display = "none";
    });

    slideIndex = (index + slides.length) % slides.length;

    slides[slideIndex].style.display = "block";
}


// NEXT AND PREVIOUS BUTTONS

function changeSlide(direction) {

    showSlide(slideIndex + direction);

}
// AUTOMATIC SLIDESHOW
if (slides.length > 0) {
    showSlide(0);
    setInterval(function() {
        showSlide(slideIndex + 1);
    }, 3000);
}

  // LIGHTBOX
const galleryImages = document.querySelectorAll(".gallery img");
const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightbox-image");
let currentImage = 0;

// OPEN LIGHTBOX
if (lightbox && lightboxImage) {

    galleryImages.forEach(function(image, index) {

        image.addEventListener("click", function() {

            currentImage = index;

            lightboxImage.src = image.src;

            lightbox.style.display = "flex";

            document.body.style.overflow = "hidden";
        });
    });
    // CLOSE LIGHTBOX
    function closeLightbox() {
        lightbox.style.display = "none";
        document.body.style.overflow = "auto";
    }
    // CHANGE LIGHTBOX IMAGE
    function lightboxChange(direction) {
        if (galleryImages.length === 0) {
            return;
        }
        currentImage =
            (currentImage + direction + galleryImages.length)  % galleryImages.length;
        lightboxImage.src = galleryImages[currentImage].src;
    }
    // CLICK OUTSIDE TO CLOSE
    lightbox.addEventListener("click", function(event) {
        if (event.target === lightbox) {
            closeLightbox();
        }

    });


    // KEYBOARD CONTROLS

    document.addEventListener("keydown", function(event) {

        if (lightbox.style.display === "flex") {

            if (event.key === "Escape") {
                closeLightbox();
            }

            if (event.key === "ArrowRight") {
                lightboxChange(1);
            }

            if (event.key === "ArrowLeft") {
                lightboxChange(-1);
            }

        }

    });

}
