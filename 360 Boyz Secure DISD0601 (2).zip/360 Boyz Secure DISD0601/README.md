//Everything about site
improvements for part 2 
<link rel="stylesheet" href="CSS/StyleSheet.css">
I downloaded and used a background image for my website using CSS
i put and improved navigation bar 
added subtle 3D aspects
updated homepage
styled service page
styled about page 
improved contact form
styled enquiry form
added glass effect to forms
imporoved button hover effect
fixed all my page spacing and alignment
for my CSS , i gave each of them their own section so that i would not get confused while i was busy and it link to each properly. 

improvements for part 3
for the final poe i am required to create a website using html , style the web pages using externat css then add html form so that i can be able to do form validation using javascript
i used java script to say when something that is invilde has been entered 
i implemented the dateTime method to keep showing time 
i add the slide show and light box that overide what i already had in my css 
 i struggled with the java script so i used w3schools for assistance 
  i added to my contact and enquiry page now the display exaples of what is expected
  i linked each page back to the javascript in order for the things to work 
  i added it to the footer 
  i added meta 
  i didnt know i had to create the index page so i did that 
  i added more css for the invalide phrases so that they turn red 
  i am going to try hosting my website on a free site 
  



  referance
  w3schools google chrome 
